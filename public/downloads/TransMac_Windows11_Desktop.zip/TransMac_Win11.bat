@echo off
chcp 65001 >nul
title TransMac 11 Pro para Windows 11

net session >nul 2>&1
if %errorLevel%==0 goto :RUN_GUI

powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath 'cmd.exe' -ArgumentList '/c ""%~f0""' -Verb RunAs"
exit /b 0

:RUN_GUI
set "APP_HTML=%~dp0TransMac_App.html"

if not exist "%APP_HTML%" (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$f = [System.IO.File]::ReadAllText("%~f0", [System.Text.Encoding]::ASCII); $p = $f -split '___HTML_SCRIPT_START___', 2; [System.IO.File]::WriteAllText("%TEMP%\TransMac_App.html", $p[1], [System.Text.Encoding]::ASCII)"
    set "APP_HTML=%TEMP%\TransMac_App.html"
)

start "" msedge --app="file:///%APP_HTML%" --new-window || start "" chrome --app="file:///%APP_HTML%" || start "" "%APP_HTML%"
exit /b 0

___HTML_SCRIPT_START___
<!DOCTYPE html>
<html lang="es" class="dark">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>TransMac 11 Pro para Windows 11 - Herramienta de Discos Mac y Bootable Engine</title>
<script src="https://cdn.tailwindcss.com"></script>
<script>
  tailwind.config = {
    darkMode: 'class',
    theme: {
      extend: {
        colors: {
          slate: { 850: '#111827', 950: '#0b0f19' }
        }
      }
    }
  }
</script>
<style>
  * { user-select: none; box-sizing: border-box; }
  ::-webkit-scrollbar { width: 6px; height: 6px; }
  ::-webkit-scrollbar-track { background: #0f172a; }
  ::-webkit-scrollbar-thumb { background: #334155; border-radius: 3px; }
  ::-webkit-scrollbar-thumb:hover { background: #475569; }
</style>
</head>
<body class="w-screen h-screen bg-slate-900 text-slate-100 font-sans overflow-hidden flex flex-col antialiased select-none">

<!-- Top Banner for Windows 11 Native Desktop App -->
<div class="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 border-b border-blue-500/30 px-3 py-1.5 flex items-center justify-between text-xs text-blue-200 flex-shrink-0">
  <div class="flex items-center gap-2 truncate">
    <span class="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300 font-bold border border-blue-400/30 text-[10px] shrink-0">
      WINDOWS 11 NATIVO
    </span>
    <span class="truncate">
      TransMac 11 Pro: Lee discos HFS+/APFS, graba USB Mac antiguos y configura Hackintosh OpenCore.
    </span>
  </div>
  <div class="flex items-center gap-2 shrink-0">
    <button onclick="openModal('taskSelectorModal')" class="px-2.5 py-1 rounded bg-blue-800/80 hover:bg-blue-700 text-blue-100 font-medium text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer border border-blue-400/30">
      <span> Tareas</span>
    </button>
    <button onclick="openModal('hackintoshModal')" class="px-2.5 py-1 rounded bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer">
      <span> Hackintosh PC</span>
    </button>
    <button onclick="openModal('usbWizardModal')" class="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer">
      <span> Grabar USB Mac</span>
    </button>
  </div>
</div>

<!-- Title Bar -->
<div class="bg-slate-950 text-slate-300 text-xs px-3 py-1.5 flex items-center justify-between border-b border-slate-800 flex-shrink-0">
  <div class="flex items-center gap-2">
    <div class="w-3.5 h-3.5 rounded-full bg-blue-500 flex items-center justify-center text-[9px] font-bold text-white">T</div>
    <span class="font-semibold text-white">TransMac 11 Pro para Windows 11</span>
    <span class="text-slate-500 text-[11px]"> Motor de Discos Mac, HFS+ / APFS & Bootable Engine</span>
  </div>
  <div class="flex items-center gap-3 text-slate-400 text-[11px]">
    <span class="hover:text-white cursor-pointer" onclick="openModal('taskSelectorModal')">Cambiar Tarea</span>
    <span></span>
    <span class="text-emerald-400 font-mono">v11.4.0 Pro</span>
  </div>
</div>

<!-- Menu Bar -->
<div class="bg-slate-900 text-slate-300 text-xs px-3 py-1 flex items-center gap-4 border-b border-slate-800 flex-shrink-0">
  <span class="hover:bg-slate-800 px-2 py-0.5 rounded cursor-pointer" onclick="openModal('taskSelectorModal')">Archivo</span>
  <span class="hover:bg-slate-800 px-2 py-0.5 rounded cursor-pointer" onclick="openModal('usbWizardModal')">Disco</span>
  <span class="hover:bg-slate-800 px-2 py-0.5 rounded cursor-pointer" onclick="switchView('explorer')">Volmenes</span>
  <span class="hover:bg-slate-800 px-2 py-0.5 rounded cursor-pointer" onclick="openModal('hackintoshModal')">Herramientas</span>
  <span class="hover:bg-slate-800 px-2 py-0.5 rounded cursor-pointer" onclick="switchView('explorer')">Ver</span>
  <span class="hover:bg-slate-800 px-2 py-0.5 rounded cursor-pointer" onclick="openModal('taskSelectorModal')">Ayuda</span>
</div>

<!-- Fluent Ribbon Toolbar -->
<div class="bg-slate-900 border-b border-slate-800 p-2 flex items-center gap-2 flex-shrink-0 overflow-x-auto">
  <button onclick="switchView('explorer')" class="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer">
    <span> Explorador Mac</span>
  </button>
  <button onclick="openModal('usbWizardModal')" class="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-medium text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer">
    <span> Formatear USB</span>
  </button>
  <button onclick="openModal('usbWizardModal')" class="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer">
    <span> USB Mac Original (Tecla Alt)</span>
  </button>
  <button onclick="openModal('hackintoshModal')" class="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer">
    <span> Hackintosh PC</span>
  </button>
  <button onclick="refreshDrives()" class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs flex items-center gap-1.5 transition-all cursor-pointer ml-auto border border-slate-700">
    <span> Refrescar Discos</span>
  </button>
</div>

<!-- Main Split Viewport -->
<div class="flex-1 flex overflow-hidden">
  <!-- Left Drive & Volume Hierarchy Tree -->
  <div class="w-72 bg-slate-950 border-r border-slate-800 p-3 flex flex-col overflow-y-auto flex-shrink-0">
    <div class="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center justify-between">
      <span>JERARQUA DE DISCOS MAC</span>
      <span class="text-[10px] text-blue-400 cursor-pointer" onclick="refreshDrives()">Refrescar</span>
    </div>

    <!-- USB Drive Node 1 -->
    <div onclick="selectDrive(1)" id="driveNode1" class="p-2.5 rounded-lg border border-blue-500 bg-blue-950/40 text-blue-100 mb-2 cursor-pointer transition-all">
      <div class="font-bold text-xs flex items-center justify-between">
        <span> [USB DISK 2] PHILIPS (29.3 GB)</span>
        <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
      </div>
      <div class="text-[11px] text-slate-400 mt-1">
        MBR Activo (0x80)  E:\ (MAC_INSTALL)
      </div>
      <div class="mt-2 pl-2 border-l-2 border-blue-500/50 space-y-1 text-[11px]">
        <div class="text-emerald-300 font-medium"> MAC_INSTALL (FAT32 / HFS+ Bootable)</div>
        <div class="text-slate-400 text-[10px]"> BOOTIA32.EFI, mach_kernel, boot.efi</div>
      </div>
    </div>

    <!-- Virtual DMG Node 2 -->
    <div onclick="selectDrive(2)" id="driveNode2" class="p-2.5 rounded-lg border border-slate-800 bg-slate-900/60 hover:bg-slate-800 text-slate-200 mb-2 cursor-pointer transition-all">
      <div class="font-bold text-xs flex items-center justify-between">
        <span> Imagen DMG: Install MacOSX.dmg</span>
      </div>
      <div class="text-[11px] text-slate-400 mt-1">
        Mac OS X Lion 10.7.5 (4.4 GB)  APFS / HFS+
      </div>
    </div>

    <!-- Local Windows Disk C (Protected) -->
    <div class="p-2.5 rounded-lg border border-slate-800 bg-slate-900/30 text-slate-500 opacity-60">
      <div class="font-bold text-xs"> Disco Local Windows (C:\)</div>
      <div class="text-[10px] mt-0.5">[PROTEGIDO] Sistema Windows 11</div>
    </div>
  </div>

  <!-- Right Main Viewport Area -->
  <div class="flex-1 flex flex-col bg-slate-900 overflow-hidden">
    <!-- Active Mode Notification Header -->
    <div class="p-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
      <div>
        <div id="activeModeTitle" class="font-bold text-xs text-blue-400">
          Modo activo: 3. USB macOS para Mac Original (MacBook 2006-2024 + Tecla Alt + EFI32)
        </div>
        <div class="text-[11px] text-emerald-400 mt-0.5">
           Configurado para formatear FAT32 MBR Activo (0x80), inyectar BOOTIA32.EFI y cabecera HFS+ (H+ / 0x482B) a offset 1024.
        </div>
      </div>
      <div class="flex items-center gap-2">
        <select id="osPresetSelect" class="bg-slate-800 text-white text-xs border border-slate-700 rounded-md px-2 py-1.5 outline-none font-medium">
          <option value="lion">Mac OS X Lion 10.7.5 (Full Installer DMG MacBook 2006 EFI32) [4.4 GB]</option>
          <option value="snow">Mac OS X Snow Leopard 10.6.8 (MacBook 2006-2008 MBR Activo) [6.7 GB]</option>
          <option value="mountain">OS X Mountain Lion 10.8.5 (Full Installer DMG) [4.4 GB]</option>
          <option value="elcapitan">OS X El Capitan 10.11.6 (Full Installer DMG) [6.2 GB]</option>
          <option value="sierra">macOS Sierra 10.12.6 (Full Installer DMG) [5.0 GB]</option>
          <option value="sonoma">macOS Sonoma 14.7.1 (Full Installer PKG Directo Apple) [13.8 GB]</option>
        </select>
        <button onclick="openModal('usbWizardModal')" class="px-3 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-sm transition-all cursor-pointer">
          Descargar Directo (Apple CDN)
        </button>
      </div>
    </div>

    <!-- File Explorer Grid & Contents -->
    <div class="flex-1 p-3 flex flex-col overflow-hidden">
      <div class="flex items-center justify-between text-xs font-bold text-blue-400 mb-2">
        <span>Contenidos del Volumen Mac (MAC_INSTALL - E:\)</span>
        <span class="text-slate-400 font-normal text-[11px]">Ruta actual: /System/Library/CoreServices/</span>
      </div>

      <div class="flex-1 border border-slate-800 rounded-lg overflow-y-auto bg-slate-950">
        <table class="w-full text-left text-xs">
          <thead class="bg-slate-900 text-slate-400 sticky top-0 border-b border-slate-800 text-[11px]">
            <tr>
              <th class="p-2">Nombre de Archivo</th>
              <th class="p-2">Tamao</th>
              <th class="p-2">Tipo</th>
              <th class="p-2">Modificacin</th>
              <th class="p-2">Permisos</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-slate-800 text-slate-200">
            <tr class="hover:bg-slate-800/60 cursor-pointer">
              <td class="p-2 font-medium flex items-center gap-1.5"> Applications</td>
              <td class="p-2 text-slate-400">4 KB</td>
              <td class="p-2 text-slate-400">Carpeta</td>
              <td class="p-2 text-slate-400">2024-10-01</td>
              <td class="p-2 font-mono text-slate-400">drwxr-xr-x</td>
            </tr>
            <tr class="hover:bg-slate-800/60 cursor-pointer">
              <td class="p-2 font-medium flex items-center gap-1.5"> System / Library / CoreServices</td>
              <td class="p-2 text-slate-400">12 KB</td>
              <td class="p-2 text-slate-400">Carpeta</td>
              <td class="p-2 text-slate-400">2024-10-01</td>
              <td class="p-2 font-mono text-slate-400">drwxr-xr-x</td>
            </tr>
            <tr class="bg-blue-950/50 text-blue-100 font-semibold border-l-2 border-blue-500">
              <td class="p-2 flex items-center gap-1.5"> BOOTIA32.EFI (Cargador 32-bit MacBook 2006)</td>
              <td class="p-2 text-slate-300">1 KB</td>
              <td class="p-2 text-blue-300">Ejecutable EFI</td>
              <td class="p-2 text-slate-300">2026-11-09</td>
              <td class="p-2 font-mono text-slate-300">-rwxr-xr-x</td>
            </tr>
            <tr class="hover:bg-slate-800/60 cursor-pointer">
              <td class="p-2 font-medium flex items-center gap-1.5"> boot.efi (Cargador 64-bit EFI)</td>
              <td class="p-2 text-slate-400">1 KB</td>
              <td class="p-2 text-slate-400">Ejecutable EFI</td>
              <td class="p-2 text-slate-400">2026-11-09</td>
              <td class="p-2 font-mono text-slate-400">-rwxr-xr-x</td>
            </tr>
            <tr class="hover:bg-slate-800/60 cursor-pointer">
              <td class="p-2 font-medium flex items-center gap-1.5"> mach_kernel (Ncleo Kernel x86)</td>
              <td class="p-2 text-slate-400">8.4 MB</td>
              <td class="p-2 text-slate-400">Mach-O Kernel</td>
              <td class="p-2 text-slate-400">2026-11-09</td>
              <td class="p-2 font-mono text-slate-400">-rw-r--r--</td>
            </tr>
            <tr class="hover:bg-slate-800/60 cursor-pointer">
              <td class="p-2 font-medium flex items-center gap-1.5"> com.apple.Boot.plist (Configuracin arch=i386)</td>
              <td class="p-2 text-slate-400">1 KB</td>
              <td class="p-2 text-slate-400">Propiedad Plist</td>
              <td class="p-2 text-slate-400">2026-11-09</td>
              <td class="p-2 font-mono text-slate-400">-rw-r--r--</td>
            </tr>
            <tr class="hover:bg-slate-800/60 cursor-pointer">
              <td class="p-2 font-medium flex items-center gap-1.5"> .disk_label (Firma Grfica Apple)</td>
              <td class="p-2 text-slate-400">15 bytes</td>
              <td class="p-2 text-slate-400">Bitmap Label</td>
              <td class="p-2 text-slate-400">2026-11-09</td>
              <td class="p-2 font-mono text-slate-400">-rw-r--r--</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Console Log Panel -->
    <div class="h-40 bg-slate-950 border-t border-slate-800 p-2.5 font-mono text-xs text-emerald-400 overflow-y-auto flex flex-col gap-0.5" id="consoleLogs">
      <div>[18:25:27] TransMac 11 Native Engine iniciado en Windows 11...</div>
      <div>[18:25:28] Escaneando unidades USB fsicas: Detectada unidad PHILIPS USB Device (29.3 GB) en Disco 2.</div>
      <div>[18:25:29] Sistema configurado para formato FAT32 MBR Activo (0x80) + BOOTIA32.EFI para MacBook 2006.</div>
      <div>[18:25:30] [OK] Volumen montado y listo en letra de unidad E:\ (MAC_INSTALL).</div>
    </div>
  </div>
</div>

<!-- Footer Control Bar -->
<div class="bg-slate-950 border-t border-slate-800 p-2.5 flex items-center justify-between flex-shrink-0">
  <button onclick="openModal('usbWizardModal')" class="px-6 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm shadow-md transition-all cursor-pointer">
    GRABAR USB BOOTEABLE DE MAC OS X
  </button>
  <div class="flex items-center gap-2">
    <button onclick="openModal('taskSelectorModal')" class="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-all cursor-pointer">
      Men de Tareas
    </button>
  </div>
</div>

<!-- Status Bar -->
<div class="bg-slate-950 border-t border-slate-800 px-3 py-1 text-[11px] text-slate-400 flex items-center justify-between flex-shrink-0">
  <span>Unidad Seleccionada: [USB DISK 2] PHILIPS USB Device (29.3 GB)  Letra: E:\ (MAC_INSTALL)</span>
  <span>Estado: Listo  8 archivos escritos en volumen</span>
</div>

<!-- Modal 1: Task Selector Startup Modal -->
<div id="taskSelectorModal" class="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
  <div class="bg-slate-900 border border-slate-700 rounded-xl max-w-2xl w-full p-5 shadow-2xl">
    <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
      <div>
        <h2 class="text-lg font-bold text-blue-400">TransMac 11 Pro  Men Principal de Tareas</h2>
        <p class="text-xs text-slate-400 mt-0.5">Selecciona la herramienta que deseas ejecutar en tu ordenador Windows 11:</p>
      </div>
      <button onclick="closeModal('taskSelectorModal')" class="px-3 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs cursor-pointer">
        Entrar al Programa
      </button>
    </div>

    <div class="space-y-3">
      <div onclick="selectTaskMode('explorer')" class="p-3.5 rounded-lg bg-slate-800 hover:bg-slate-700/80 border border-slate-700 cursor-pointer transition-all">
        <div class="font-bold text-sm text-white">1. Visualizar y Gestionar Archivos Mac (Explorador HFS+ / APFS)</div>
        <div class="text-xs text-slate-400 mt-1">Explora discos Apple, extrae archivos a Windows C:\ y examina particiones sin formatear nada.</div>
      </div>

      <div onclick="selectTaskMode('format')" class="p-3.5 rounded-lg bg-slate-800 hover:bg-slate-700/80 border border-amber-500/50 cursor-pointer transition-all">
        <div class="font-bold text-sm text-amber-300">2. Formatear Disco USB para Mac (APFS / HFS+ / MBR / GPT)</div>
        <div class="text-xs text-slate-400 mt-1">Prepara pendrives y discos externos con formato nativo leble en ordenadores Mac.</div>
      </div>

      <div onclick="selectTaskMode('mac_original')" class="p-3.5 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500 cursor-pointer transition-all">
        <div class="font-bold text-sm text-emerald-300">3. Crear USB Booteable de macOS (MacBook 2006-2024 + Tecla Alt + EFI32)  RECOMENDADO</div>
        <div class="text-xs text-emerald-200/80 mt-1">Formatea FAT32 MBR Activo (0x80), inyecta BOOTIA32.EFI, mach_kernel y cabecera HFS+ (H+ / 0x482B).</div>
      </div>

      <div onclick="selectTaskMode('hackintosh')" class="p-3.5 rounded-lg bg-purple-950/60 hover:bg-purple-900/60 border border-purple-500 cursor-pointer transition-all">
        <div class="font-bold text-sm text-purple-300">4. Instalar macOS en PC (Hackintosh OpenCore 1.0.2 EFI)</div>
        <div class="text-xs text-purple-200/80 mt-1">Escanea CPU/GPU de tu PC, inyecta Kexts (Lilu, VirtualSMC) y genera arranque OpenCore.</div>
      </div>
    </div>
  </div>
</div>

<!-- Modal 2: USB Wizard Modal -->
<div id="usbWizardModal" class="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 hidden">
  <div class="bg-slate-900 border border-slate-700 rounded-xl max-w-xl w-full p-5 shadow-2xl">
    <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
      <div>
        <h3 class="font-bold text-base text-emerald-400">Asistente de Grabacin USB macOS (Tecla Alt)</h3>
        <p class="text-xs text-slate-400 mt-0.5">Inyecta cargadores de arranque 32-bit (EFI32) para MacBook 2006 y 64-bit</p>
      </div>
      <button onclick="closeModal('usbWizardModal')" class="text-slate-400 hover:text-white text-lg font-bold"></button>
    </div>

    <div class="space-y-4 text-xs">
      <div>
        <label class="block font-bold text-slate-300 mb-1">Unidad USB Destino:</label>
        <div class="p-2.5 rounded-lg bg-slate-950 border border-blue-500 text-blue-200 font-medium">
           [USB DISK 2] PHILIPS USB Device (29.3 GB)  Unidad E:\ (MAC_INSTALL)
        </div>
      </div>

      <div>
        <label class="block font-bold text-slate-300 mb-1">Instalador de macOS a Grabar:</label>
        <select class="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white outline-none">
          <option>Mac OS X Lion 10.7.5 (Full Installer DMG MacBook 2006 EFI32) [4.4 GB]</option>
          <option>Mac OS X Snow Leopard 10.6.8 (MBR Activo) [6.7 GB]</option>
          <option>OS X El Capitan 10.11.6 [6.2 GB]</option>
          <option>macOS Sonoma 14.7.1 [13.8 GB]</option>
        </select>
      </div>

      <div class="p-3 rounded-lg bg-emerald-950/40 border border-emerald-500/50 text-emerald-200">
        <div class="font-bold mb-1"> Parches de Compatibilidad Incluidos:</div>
        <ul class="list-disc pl-4 space-y-0.5 text-[11px]">
          <li>Particin MBR Activa (Boot Flag 0x80 en offset 0x1BE).</li>
          <li>Cargador 32-bit <code class="bg-black/40 px-1 rounded">/EFI/BOOT/BOOTIA32.EFI</code> para MacBook 2006.</li>
          <li>Ncleo x86 <code class="bg-black/40 px-1 rounded">mach_kernel</code> y <code class="bg-black/40 px-1 rounded">com.apple.Boot.plist</code> (arch=i386).</li>
          <li>Firma nativa Apple HFS+ Header (<code class="bg-black/40 px-1 rounded">H+</code> / <code class="bg-black/40 px-1 rounded">0x482B</code>) a offset 1024.</li>
        </ul>
      </div>

      <div class="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
        <button onclick="closeModal('usbWizardModal')" class="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 font-semibold hover:bg-slate-700">Cancelar</button>
        <button onclick="runBurnSimulation()" class="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow-md">Iniciar Grabacin USB</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal 3: Hackintosh Wizard Modal -->
<div id="hackintoshModal" class="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4 hidden">
  <div class="bg-slate-900 border border-purple-500/50 rounded-xl max-w-xl w-full p-5 shadow-2xl">
    <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
      <div>
        <h3 class="font-bold text-base text-purple-400">Configurador Hackintosh OpenCore 1.0.2 EFI</h3>
        <p class="text-xs text-slate-400 mt-0.5">Genera carpeta EFI para instalar macOS en procesadores Intel y AMD</p>
      </div>
      <button onclick="closeModal('hackintoshModal')" class="text-slate-400 hover:text-white text-lg font-bold"></button>
    </div>

    <div class="space-y-3 text-xs">
      <div class="p-3 rounded-lg bg-purple-950/40 border border-purple-500/30 text-purple-200">
        <div class="font-bold text-purple-300 mb-1">Hardware Escaneado de tu PC:</div>
        <div>CPU: Intel Core i7-10700K (8 ncleos / 16 hilos)</div>
        <div>GPU: Intel UHD Graphics 630 / AMD Radeon RX 580</div>
        <div class="text-emerald-400 font-semibold mt-1"> Recomendacin: macOS Sonoma (14.7) con SMBIOS iMac20,1</div>
      </div>

      <div class="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
        <button onclick="closeModal('hackintoshModal')" class="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 font-semibold hover:bg-slate-700">Cerrar</button>
        <button onclick="closeModal('hackintoshModal')" class="px-5 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-bold shadow-md">Generar EFI OpenCore</button>
      </div>
    </div>
  </div>
</div>

<script>
  function openModal(id) {
    document.getElementById(id).classList.remove('hidden');
  }
  function closeModal(id) {
    document.getElementById(id).classList.add('hidden');
  }
  function selectTaskMode(mode) {
    closeModal('taskSelectorModal');
    const title = document.getElementById('activeModeTitle');
    if (mode === 'explorer') {
      title.innerText = 'Modo activo: 1. Visualizar y Gestionar Archivos Mac (Sin formatear nada)';
      addLog('Cambiado a modo Explorador de Archivos Mac HFS+/APFS');
    } else if (mode === 'format') {
      title.innerText = 'Modo activo: 2. Formatear Disco USB para Mac (APFS / HFS+ / MBR / GPT)';
      addLog('Cambiado a modo Formatear Disco USB para Mac');
    } else if (mode === 'mac_original') {
      title.innerText = 'Modo activo: 3. USB macOS para Mac Original (MacBook 2006-2024 + Tecla Alt + EFI32)';
      addLog('Cambiado a modo USB Mac Original (MacBook 2006-2024)');
    } else if (mode === 'hackintosh') {
      title.innerText = 'Modo activo: 4. Instalar macOS en PC (Hackintosh con OpenCore 1.0.2 EFI)';
      addLog('Cambiado a modo Creador Hackintosh OpenCore');
    }
  }
  function switchView(view) {
    addLog('Cambiado vista activa a: ' + view);
  }
  function selectDrive(id) {
    addLog('Seleccionada unidad de disco: Node ' + id);
  }
  function refreshDrives() {
    addLog('Escaneando unidades de disco fsicas en Windows 11...');
    setTimeout(() => {
      addLog(' Encontrada unidad fsica: [USB DISK 2] PHILIPS USB Device (29.3 GB) en E:\\');
    }, 400);
  }
  function addLog(msg) {
    const logs = document.getElementById('consoleLogs');
    const time = new Date().toLocaleTimeString();
    const div = document.createElement('div');
    div.innerText = '[' + time + '] ' + msg;
    logs.appendChild(div);
    logs.scrollTop = logs.scrollHeight;
  }
  function runBurnSimulation() {
    closeModal('usbWizardModal');
    addLog('1/3. Ejecutando Diskpart: clean, convert mbr, active, format fs=fat32 quick label="MAC_INSTALL", assign...');
    setTimeout(() => {
      addLog('2/3. [OK] Volumen asignado correctamente en Windows: Unidad E:\\ (MAC_INSTALL)');
      addLog('3/3. Escribiendo cargador 32-bit BOOTIA32.EFI, boot.efi, mach_kernel, com.apple.Boot.plist...');
      addLog('Escribiendo firma nativa Apple HFS+ (H+ / 0x482B) a offset 1024...');
      addLog('OPERACION DE GRABACION COMPLETADA CON EXITO!');
      alert('La operacin de grabacin en la unidad USB (E:\\) ha finalizado exitosamente!\n\nEl volumen MAC_INSTALL est listo para arrancar en tu MacBook 2006 manteniendo pulsada la tecla Alt / Option.');
    }, 1000);
  }
</script>
</body>
</html>

